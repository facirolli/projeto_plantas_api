<?php
require_once __DIR__ . '/../service/CuidadoService.php';
require_once __DIR__ . '/../service/UsuarioService.php';
require_once __DIR__ . '/../service/PlantaService.php';

class CuidadoController {
    private $service;
    private $usuarioService;
    private $plantaService;

    public function __construct() {
        $this->service = new CuidadoService();
        $this->usuarioService = new UsuarioService();
        $this->plantaService = new PlantaService();
    }

    // Listar todos os cuidados
    public function listar() {
        $cuidados = $this->service->listar();
        require __DIR__ . '/../public/cuidado/listar.php';
    }

    // Criar novo cuidado
    public function criar() {
        $erro = '';
        $cuidado = [];

        // Carregar usuários e plantas
        $usuarios = $this->usuarioService->listar();
        $plantas  = $this->plantaService->listar();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            require __DIR__ . '/../public/cuidado/form.php';
            return;
        }

        $usuario_id   = trim($_POST['usuario_id'] ?? '');
        $planta_id    = trim($_POST['planta_id'] ?? '');
        $tipo_cuidado = trim($_POST['tipo_cuidado'] ?? '');
        $frequencia   = trim($_POST['frequencia'] ?? '');

        if (!$usuario_id || !$planta_id || !$tipo_cuidado || !$frequencia) {
            $erro = "Todos os campos são obrigatórios.";
            require __DIR__ . '/../public/cuidado/form.php';
            return;
        }

        $this->service->inserir([
            'usuario_id'   => $usuario_id,
            'planta_id'    => $planta_id,
            'tipo_cuidado' => $tipo_cuidado,
            'frequencia'   => $frequencia
        ]);

        header("Location: index.php?controller=Cuidado&action=listar");
        exit;
    }

    // Editar cuidado existente
    public function editar($id) {
        $erro = '';
        $cuidado = $this->service->buscarPorId($id);

        if (!$cuidado) {
            die('Cuidado não encontrado.');
        }

        // Carregar usuários e plantas
        $usuarios = $this->usuarioService->listar();
        $plantas  = $this->plantaService->listar();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            require __DIR__ . '/../public/cuidado/form.php';
            return;
        }

        $usuario_id   = trim($_POST['usuario_id'] ?? '');
        $planta_id    = trim($_POST['planta_id'] ?? '');
        $tipo_cuidado = trim($_POST['tipo_cuidado'] ?? '');
        $frequencia   = trim($_POST['frequencia'] ?? '');

        if (!$usuario_id || !$planta_id || !$tipo_cuidado || !$frequencia) {
            $erro = "Todos os campos são obrigatórios.";
            require __DIR__ . '/../public/cuidado/form.php';
            return;
        }

        $this->service->atualizar($id, [
            'usuario_id'   => $usuario_id,
            'planta_id'    => $planta_id,
            'tipo_cuidado' => $tipo_cuidado,
            'frequencia'   => $frequencia
        ]);

        header("Location: index.php?controller=Cuidado&action=listar");
        exit;
    }

    // Deletar cuidado
    public function deletar($id) {
        $this->service->deletar($id);
        header("Location: index.php?controller=Cuidado&action=listar");
        exit;
    }
}
