<?php
require_once __DIR__ . '/../service/UsuarioService.php';

class UsuarioController {
    private $service;

    public function __construct() {
        $this->service = new UsuarioService();
    }

    public function listar() {
        // Corrigido: variável em minúsculo
        $usuarios = $this->service->listar();
        require __DIR__ . '/../public/usuario/listar.php';
    }

    public function criar() {
        $erro = '';
        $usuario = [];

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            require __DIR__ . '/../public/usuario/form.php';
            return;
        }

        $nome = trim($_POST['nome'] ?? '');
        $email = trim($_POST['email'] ?? '');

        if (!$nome || !$email) {
            $erro = "Nome e email são obrigatórios.";
            require __DIR__ . '/../public/usuario/form.php';
            return;
        }

        $this->service->inserir(['nome' => $nome, 'email' => $email]);

        header("Location: index.php?controller=Usuario&action=listar");
        exit;
    }

    public function editar($id) {
        $erro = '';
        $usuario = $this->service->buscarPorId($id);

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            require __DIR__ . '/../public/usuario/form.php';
            return;
        }

        $nome = trim($_POST['nome'] ?? '');
        $email = trim($_POST['email'] ?? '');

        if (!$nome || !$email) {
            $erro = "Nome e email são obrigatórios.";
            require __DIR__ . '/../public/usuario/form.php';
            return;
        }

        $this->service->atualizar($id, ['nome' => $nome, 'email' => $email]);

        header("Location: index.php?controller=Usuario&action=listar");
        exit;
    }

    public function deletar($id) {
        $this->service->deletar($id);
        header("Location: index.php?controller=Usuario&action=listar");
        exit;
    }
}
