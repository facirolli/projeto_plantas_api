<?php
require_once __DIR__ . '/../service/PlantaService.php';
require_once __DIR__ . '/../service/CuidadoService.php';

class PlantaController {
    private $service;
    private $cuidadoService;

    public function __construct() {
        $this->service = new PlantaService(); // sem \Service
        $this->cuidadoService = new CuidadoService();
    }

    public function listar() {
        $plantas = $this->service->listar();
        require __DIR__ . '/../public/planta/listar.php';
    }

    public function criar() {
        $erro = '';
        $planta = [];

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            require __DIR__ . '/../public/planta/form.php';
            return;
        }

        $nome_cientifico = trim($_POST['nome_cientifico'] ?? '');
        $nome_popular = trim($_POST['nome_popular'] ?? '');

        if (!$nome_cientifico || !$nome_popular) {
            $erro = "Todos os campos são obrigatórios.";
            require __DIR__ . '/../public/planta/form.php';
            return;
        }

        $result = $this->service->inserir([
            'nome_cientifico' => $nome_cientifico,
            'nome_popular' => $nome_popular
        ]);

        if (!$result) {
            $erro = 'Erro ao inserir planta.';
            require __DIR__ . '/../public/planta/form.php';
            return;
        }

        header("Location: index.php?controller=Planta&action=listar");
        exit;
    }

    public function editar($id) {
        $erro = '';
        $planta = $this->service->buscarPorId($id); // usar buscarPorId

        if (!$planta) {
            die('Planta não encontrada.');
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            require __DIR__ . '/../public/planta/form.php';
            return;
        }

        $nome_cientifico = trim($_POST['nome_cientifico'] ?? '');
        $nome_popular = trim($_POST['nome_popular'] ?? '');

        if (!$nome_cientifico || !$nome_popular) {
            $erro = "Todos os campos são obrigatórios.";
            require __DIR__ . '/../public/planta/form.php';
            return;
        }

        $result = $this->service->atualizar($id, [
            'nome_cientifico' => $nome_cientifico,
            'nome_popular' => $nome_popular
        ]);

        if (!$result) {
            $erro = 'Erro ao atualizar planta.';
            require __DIR__ . '/../public/planta/form.php';
            return;
        }

        header("Location: index.php?controller=Planta&action=listar");
        exit;
    }

    public function deletar($id) {
        $this->service->deletar($id);
        header("Location: index.php?controller=Planta&action=listar");
        exit;
    }
}
