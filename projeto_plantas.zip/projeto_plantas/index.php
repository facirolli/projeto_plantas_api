<?php
require_once __DIR__ . '/generic/Autoload.php';

$controllerName = $_GET['controller'] ?? null;
$action = $_GET['action'] ?? null;
$id = $_GET['id'] ?? null;

if (!$controllerName && !$action) {
    ?>
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <title>Projeto Doações</title>
        <link rel="stylesheet" href="css/style.css">
        <style>
            .dashboard {
                display: flex;
                justify-content: center;
                align-items: center;
                flex-wrap: wrap;
                gap: 3%;
                margin-top: 5%;
            }
            .card {
                background: #fff;
                width: 25%;
                min-width: 220px;
                padding: 3%;
                border-radius: 1rem;
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                text-align: center;
                transition: transform 0.2s ease-in-out;
            }
            .card:hover {
                transform: translateY(-5px);
            }
            .card h2 {
                margin-bottom: 8%;
                color: #2c3e50;
            }
            .card a {
                display: inline-block;
                margin-top: 5%;
                padding: 8% 12%;
                background-color: #3498db;
                color: #fff;
                border-radius: 0.5rem;
                font-size: 1rem;
                font-weight: bold;
                transition: background 0.3s;
            }
            .card a:hover {
                background-color: #2980b9;
            }
        </style>
    </head>
    <body>
        <h1>🌿 Plataforma de Plantas 🌿</h1>
       

        <div class="dashboard">
            <div class="card">
                <h2>😃 Usuarios</h2>
                <p>Gerencie os usuarios</p>
                <a href="index.php?controller=Usuario&action=listar">Acessar</a>
            </div>

            <div class="card">
                <h2>🥦 Plantas</h2>
                <p>Gerencie as plantas</p>
                <a href="index.php?controller=Planta&action=listar">Acessar</a>
            </div>

            <div class="card">
                <h2>✔ Cuidados</h2>
                <p>Gerencie os cuidados</p>
                <a href="index.php?controller=Cuidado&action=listar">Acessar</a>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}

$controllerClass = $controllerName . 'Controller';
$controllerFile = __DIR__ . '/controller/' . $controllerClass . '.php';

if (!file_exists($controllerFile)) {
    die("Erro: Controller '$controllerName' não encontrado.");
}

require_once $controllerFile;

if (!class_exists($controllerClass)) {
    die("Erro: Classe '$controllerClass' não definida.");
}

$controller = new $controllerClass();

if (!$action || !method_exists($controller, $action)) {
    die("Erro: Ação '$action' não encontrada no controller '$controllerClass'.");
}

$id ? $controller->$action($id) : $controller->$action();
