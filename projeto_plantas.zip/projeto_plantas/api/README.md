# API - Plantas (Documentação rápida)

Base URL (local): http://localhost/api/index.php

Recursos:
- /plantas
- /Cuidado
- /Usuario

Operações:
GET /plantas
GET /plantas/{id}
POST /plantas
PUT /plantas/{id}
DELETE /plantas/{id}

GET /cuidado
GET /cuidado/{id}
POST /cuidado
PUT /cuidado/{id}
DELETE /cuidado/{id}

GET /usuario
GET /usuario/{id}
POST /usuario
PUT /usuario/{id}
DELETE /usuario/{id}
