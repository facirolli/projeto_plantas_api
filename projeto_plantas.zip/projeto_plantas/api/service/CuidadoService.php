<?php
namespace Service;

use DAO\CuidadoDAO;

class CuidadoService {
    private $dao;

    public function __construct() {
        $this->dao = new CuidadoDAO();
    }

    public function listar() {
        try {
            return [
                'success' => true,
                'data' => $this->dao->findAll()
            ];

        } catch (\Exception $e) {
            error_log($e->getMessage());
            return [
                'success' => false,
                'message' => 'Erro ao listar cuidados'
            ];
        }
    }

    public function buscar($id) {
        try {
            $obj = $this->dao->findById($id);

            if (!$obj) {
                return [
                    'success' => false,
                    'message' => 'Cuidado não encontrado'
                ];
            }

            return [
                'success' => true,
                'data' => $obj
            ];

        } catch (\Exception $e) {
            error_log($e->getMessage());
            return [
                'success' => false,
                'message' => 'Erro ao buscar cuidado'
            ];
        }
    }

    public function inserir($data) {
        try {
            $errors = [];

            if (empty($data['usuario_id'])) {
                $errors['usuario_id'] = 'Usuário é obrigatório';
            }
            if (empty($data['planta_id'])) {
                $errors['planta_id'] = 'Planta é obrigatória';
            }
            if (empty($data['tipo_cuidado'])) {
                $errors['tipo_cuidado'] = 'Tipo de cuidado é obrigatório';
            }
            if (empty($data['frequencia'])) {
                $errors['frequencia'] = 'Frequência é obrigatória';
            }

            if (!empty($errors)) {
                return [
                    'success' => false,
                    'message' => 'Dados inválidos',
                    'errors' => $errors
                ];
            }

            $insertId = $this->dao->insert([
                'usuario_id'  => $data['usuario_id'],
                'planta_id'   => $data['planta_id'],
                'tipo_cuidado'=> $data['tipo_cuidado'],
                'frequencia'  => $data['frequencia']
            ]);

            if ($insertId) {
                $obj = $this->dao->findById($insertId);
                return [
                    'success' => true,
                    'data' => $obj
                ];
            }

            return [
                'success' => false,
                'message' => 'Erro ao inserir cuidado'
            ];

        } catch (\Exception $e) {
            error_log($e->getMessage());
            return [
                'success' => false,
                'message' => 'Erro ao processar requisição'
            ];
        }
    }

    public function atualizar($id, $data) {
        try {
            $exists = $this->dao->findById($id);

            if (!$exists) {
                return [
                    'success' => false,
                    'message' => 'Cuidado não encontrado'
                ];
            }

            $errors = [];

            if (isset($data['usuario_id']) && empty($data['usuario_id'])) {
                $errors['usuario_id'] = 'Usuário é obrigatório';
            }
            if (isset($data['planta_id']) && empty($data['planta_id'])) {
                $errors['planta_id'] = 'Planta é obrigatória';
            }
            if (isset($data['tipo_cuidado']) && empty($data['tipo_cuidado'])) {
                $errors['tipo_cuidado'] = 'Tipo de cuidado é obrigatório';
            }
            if (isset($data['frequencia']) && empty($data['frequencia'])) {
                $errors['frequencia'] = 'Frequência é obrigatória';
            }

            if (!empty($errors)) {
                return [
                    'success' => false,
                    'message' => 'Dados inválidos',
                    'errors' => $errors
                ];
            }

            $ok = $this->dao->update($id, [
                'usuario_id'  => $data['usuario_id']  ?? $exists['usuario_id'],
                'planta_id'   => $data['planta_id']   ?? $exists['planta_id'],
                'tipo_cuidado'=> $data['tipo_cuidado']?? $exists['tipo_cuidado'],
                'frequencia'  => $data['frequencia']  ?? $exists['frequencia'],
            ]);

            if ($ok) {
                $obj = $this->dao->findById($id);
                return [
                    'success' => true,
                    'data' => $obj
                ];
            }

            return [
                'success' => false,
                'message' => 'Erro ao atualizar cuidado'
            ];

        } catch (\Exception $e) {
            error_log($e->getMessage());
            return [
                'success' => false,
                'message' => 'Erro ao processar requisição'
            ];
        }
    }

    public function deletar($id) {
        try {
            $exists = $this->dao->findById($id);

            if (!$exists) {
                return [
                    'success' => false,
                    'message' => 'Cuidado não encontrado'
                ];
            }

            $ok = $this->dao->delete($id);

            if ($ok) {
                return ['success' => true];
            }

            return [
                'success' => false,
                'message' => 'Erro ao deletar cuidado'
            ];

        } catch (\Exception $e) {
            error_log($e->getMessage());
            return [
                'success' => false,
                'message' => 'Erro ao processar requisição'
            ];
        }
    }
}
