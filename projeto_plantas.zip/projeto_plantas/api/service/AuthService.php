<?php
namespace Service;

use Generic\MysqlFactory;
use Generic\JwtHelper;
use PDO;

class AuthService {

    public function login($username, $senha) {
        try {
            $pdo = MysqlFactory::getConnection();

            $stmt = $pdo->prepare("SELECT id, username, senha_hash, tipo FROM usuarioadm WHERE username = :u");
            $stmt->execute([':u' => $username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                return [
                    'ok' => false,
                    'message' => 'Usuário não encontrado',
                    'data' => null
                ];
            }

            $senhaHash = hash("sha256", $senha);

            if ($user['senha_hash'] !== $senhaHash) {
                return [
                    'ok' => false,
                    'message' => 'Senha incorreta',
                    'data' => null
                ];
            }

            $payload = [
                'id' => $user['id'],
                'username' => $user['username'],
                'tipo' => $user['tipo'],
                'exp' => time() + 3600
            ];

            $token = JwtHelper::gerarToken($payload);

            return [
                'ok' => true,
                'message' => 'Login realizado com sucesso',
                'data' => [
                    'token' => $token,
                    'user' => $payload
                ]
            ];

        } catch (\Exception $e) {
            return [
                'ok' => false,
                'message' => 'Erro interno: ' . $e->getMessage(),
                'data' => null
            ];
        }
    }
}
