<?php
namespace Service;

use DAO\PlantaDAO;

class PlantaService {
    private $dao;

    public function __construct() {
        $this->dao = new PlantaDAO();
    }

    public function listar() {
        try {
            $plantas = $this->dao->findAll();
            return ['success' => true, 'data' => $plantas];
        } catch (\Exception $e) {
            error_log($e->getMessage());
            return ['success' => false, 'message' => 'Erro ao listar plantas'];
        }
    }

    public function buscar($id) {
        try {
            $planta = $this->dao->findById($id);
            if (!$planta) {
                return ['success' => false, 'message' => 'Planta não encontrada'];
            }
            return ['success' => true, 'data' => $planta];
        } catch (\Exception $e) {
            error_log($e->getMessage());
            return ['success' => false, 'message' => 'Erro ao buscar planta'];
        }
    }

    public function inserir($data) {
        try {
            $errors = [];

            if (empty($data['nome_cientifico'])) {
                $errors['nome_cientifico'] = 'Nome científico é obrigatório';
            }

            if (empty($data['nome_popular'])) {
                $errors['nome_popular'] = 'Nome popular é obrigatório';
            }

            if (!empty($errors)) {
                return ['success' => false, 'message' => 'Dados inválidos', 'errors' => $errors];
            }

            $insertId = $this->dao->insert([
                'nome_cientifico' => $data['nome_cientifico'],
                'nome_popular' => $data['nome_popular']
            ]);

            $planta = $this->dao->findById($insertId);
            return ['success' => true, 'data' => $planta];

        } catch (\Exception $e) {
            error_log($e->getMessage());
            return ['success' => false, 'message' => 'Erro ao inserir planta'];
        }
    }

    public function atualizar($id, $data) {
        try {
            $exists = $this->dao->findById($id);
            if (!$exists) {
                return ['success' => false, 'message' => 'Planta não encontrada'];
            }

            $updateData = [
                'nome_cientifico' => $data['nome_cientifico'] ?? $exists['nome_cientifico'],
                'nome_popular' => $data['nome_popular'] ?? $exists['nome_popular']
            ];

            $ok = $this->dao->update($id, $updateData);
            if ($ok) {
                return ['success' => true, 'data' => $this->dao->findById($id)];
            }

            return ['success' => false, 'message' => 'Erro ao atualizar planta'];

        } catch (\Exception $e) {
            error_log($e->getMessage());
            return ['success' => false, 'message' => 'Erro ao processar requisição'];
        }
    }

    public function deletar($id) {
        try {
            $exists = $this->dao->findById($id);
            if (!$exists) {
                return ['success' => false, 'message' => 'Planta não encontrada'];
            }

            $ok = $this->dao->delete($id);
            return $ok ? ['success' => true] : ['success' => false, 'message' => 'Erro ao deletar planta'];

        } catch (\Exception $e) {
            error_log($e->getMessage());
            return ['success' => false, 'message' => 'Erro ao processar requisição'];
        }
    }
}
