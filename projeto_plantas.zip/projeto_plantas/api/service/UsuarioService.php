<?php
namespace Service;

use DAO\UsuarioDAO;

class UsuarioService {
    private $dao;

    public function __construct() {
        $this->dao = new UsuarioDAO();
    }

    public function listar() {
        try {
            return [
                'success' => true,
                'data' => $this->dao->findAll()
            ];

        } catch (\Exception $e) {
            error_log($e->getMessage());
            return [
                'success' => false,
                'message' => 'Erro ao listar usuarios'
            ];
        }
    }

    public function buscar($id) {
        try {
            $obj = $this->dao->findById($id);

            if (!$obj) {
                return [
                    'success' => false,
                    'message' => 'Usuario não encontrado'
                ];
            }

            return [
                'success' => true,
                'data' => $obj
            ];

        } catch (\Exception $e) {
            error_log($e->getMessage());
            return [
                'success' => false,
                'message' => 'Erro ao buscar usuario'
            ];
        }
    }

    public function inserir($data) {
        try {
            $errors = [];

            if (empty($data['nome'])) {
                $errors['nome'] = 'Nome é obrigatório';
            }

            if (!empty($data['email']) &&
                !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                $errors['email'] = 'Email inválido';
            }

            if (!empty($errors)) {
                return [
                    'success' => false,
                    'message' => 'Dados inválidos',
                    'errors' => $errors
                ];
            }

            $insertId = $this->dao->insert([
                'nome' => $data['nome'] ?? null,
                'email' => $data['email'] ?? null,
            ]);

            if ($insertId) {
                $obj = $this->dao->findById($insertId);
                return [
                    'success' => true,
                    'data' => $obj
                ];
            }

            return [
                'success' => false,
                'message' => 'Erro ao inserir usuario'
            ];

        } catch (\Exception $e) {
            error_log($e->getMessage());
            return [
                'success' => false,
                'message' => 'Erro ao processar requisição'
            ];
        }
    }

    public function atualizar($id, $data) {
        try {
            $exists = $this->dao->findById($id);

            if (!$exists) {
                return [
                    'success' => false,
                    'message' => 'Usuario não encontrado'
                ];
            }

            $errors = [];

            if (isset($data['email']) &&
                !empty($data['email']) &&
                !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {

                $errors['email'] = 'Email inválido';
            }

            if (!empty($errors)) {
                return [
                    'success' => false,
                    'message' => 'Dados inválidos',
                    'errors' => $errors
                ];
            }

            $ok = $this->dao->update($id, [
                'nome' => $data['nome'] ?? $exists['nome'],
                'email' => $data['email'] ?? $exists['email'],
            ]);

            if ($ok) {
                $obj = $this->dao->findById($id);
                return [
                    'success' => true,
                    'data' => $obj
                ];
            }

            return [
                'success' => false,
                'message' => 'Erro ao atualizar usuario'
            ];

        } catch (\Exception $e) {
            error_log($e->getMessage());
            return [
                'success' => false,
                'message' => 'Erro ao processar requisição'
            ];
        }
    }

    public function deletar($id) {
        try {
            $exists = $this->dao->findById($id);

            if (!$exists) {
                return [
                    'success' => false,
                    'message' => 'Usuario não encontrado'
                ];
            }

            $ok = $this->dao->delete($id);

            if ($ok) {
                return ['success' => true];
            }

            return [
                'success' => false,
                'message' => 'Erro ao deletar usuario'
            ];

        } catch (\Exception $e) {
            error_log($e->getMessage());
            return [
                'success' => false,
                'message' => 'Erro ao processar requisição'
            ];
        }
    }
}
