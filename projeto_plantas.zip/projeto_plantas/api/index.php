<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/Generic/Autoload.php';

use Generic\Rotas;

$rotas = new Rotas();
$rotas->processar();
