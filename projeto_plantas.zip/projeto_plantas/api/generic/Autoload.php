<?php
spl_autoload_register(function ($class) {
    $prefixes = [
        'Generic\\' => __DIR__ . '/',
        'Controller\\' => __DIR__ . '/../Controller/',
        'Service\\' => __DIR__ . '/../Service/',
        'DAO\\' => __DIR__ . '/../DAO/',
    ];

    foreach ($prefixes as $prefix => $baseDir) {
        if (strpos($class, $prefix) === 0) {
            $relative = substr($class, strlen($prefix));
            $file = $baseDir . str_replace('\\', '/', $relative) . '.php';
            if (file_exists($file)) {
                require_once $file;
            }
            return;
        }
    }
});
