<?php
namespace Generic;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class JwtHandler {

    public static function gerarToken(array $payload): string {
        $secret = JWT_SECRET;
        $now = time();
        $exp = $now + (60 * 60 * 4);

        $tokenPayload = array_merge($payload, [
            'iat' => $now,
            'exp' => $exp
        ]);

        return JWT::encode($tokenPayload, $secret, 'HS256');
    }


    public static function validarToken(string $token) {
        if (!$token) return false;

        try {
            $secret = JWT_SECRET;
            $decoded = JWT::decode($token, new Key($secret, 'HS256'));
            return (array)$decoded;
        } catch (\Exception $e) {
            return false;
        }
    }


    public static function extrairTokenDoHeader() {
        $hdr = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['Authorization'] ?? null);

        if (!$hdr) return null;

        if (stripos($hdr, 'Bearer ') === 0) {
            return trim(substr($hdr, 7));
        }

        return null;
    }
}
