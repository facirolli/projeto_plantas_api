<?php
namespace Generic;

class MysqlFactory {
    public static function getConnection() {
        return MysqlSingleton::getInstance();
    }
}
