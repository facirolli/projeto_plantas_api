<?php
namespace Generic;

class Rotas {

    public function processar() {

        $method = $_SERVER['REQUEST_METHOD'];

        $pathInfo = $_SERVER['REQUEST_URI'];
        $path = parse_url($pathInfo, PHP_URL_PATH);

        $segments = array_values(array_filter(explode('/', $path)));

        $validEntities = [
            'login', 'usuario', 'usuarios',
            'cuidado', 'cuidados',
            'planta', 'plantas'
        ];

        $entity = null;
        $index = null;

        foreach ($segments as $i => $seg) {
            $segLower = strtolower($seg);
            if (in_array($segLower, $validEntities)) {
                $entity = $segLower;
                $index = $i;
                break;
            }
        }

        if (!$entity) {
            Retorno::error('Recurso não encontrado', 404);
        }

        $id = $segments[$index + 1] ?? null;

        $map = [
            'login'        => 'Controller\\Auth',

            'usuario'       => 'Controller\\Usuario',
            'usuarios'     => 'Controller\\Usuario',

            'cuidado'  => 'Controller\\Cuidado',
            'cuidados' => 'Controller\\Cuidado',

            'planta'       => 'Controller\\Planta',
            'plantas'      => 'Controller\\Planta',
        ];

        if (!isset($map[$entity])) {
            Retorno::error("Recurso não encontrado: $entity", 404);
        }

        if ($method === 'GET' && !$id)       $acao = Acao::LIST;
        elseif ($method === 'GET')           $acao = Acao::GET;
        elseif ($method === 'POST')          $acao = Acao::CREATE;
        elseif ($method === 'PUT')           $acao = Acao::UPDATE;
        elseif ($method === 'DELETE')        $acao = Acao::DELETE;
        else Retorno::error("Método não suportado", 405);

        if ($entity !== 'login') {
            $payload = AuthMiddleware::proteger();
            $_REQUEST['auth'] = $payload;
        }

        $controllerClass = $map[$entity];
        $endpoint = new Endpoint($controllerClass);
        $endpoint->run($acao, $id);
    }
}
