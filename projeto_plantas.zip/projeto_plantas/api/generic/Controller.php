<?php
namespace Generic;

abstract class Controller {

    protected function getJsonInput() {

        $raw = trim(file_get_contents('php://input'));

        if ($raw === '' || $raw === null) {
            return [];
        }

        $json = json_decode($raw, true);

        if (json_last_error() === JSON_ERROR_NONE && is_array($json)) {
            return $json;
        }

        return [];
    }

    protected function sendSuccess($data = null, $message = 'OK', $code = 200) {
        Retorno::success($data, $message, $code);
    }

    protected function sendError($message = 'Erro', $code = 400, $data = null) {
        Retorno::error($message, $code, $data);
    }
}
