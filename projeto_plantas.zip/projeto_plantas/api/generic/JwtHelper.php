<?php
namespace Generic;

class JwtHelper {

    public static function gerarToken($payload) {
        $header = ['alg' => 'HS256', 'typ' => 'JWT'];
        $secret = JWT_SECRET;

        $headerEncoded = self::base64UrlEncode(json_encode($header));
        $payloadEncoded = self::base64UrlEncode(json_encode($payload));
        $signature = self::base64UrlEncode(
            hash_hmac('sha256', "$headerEncoded.$payloadEncoded", $secret, true)
        );

        return "$headerEncoded.$payloadEncoded.$signature";
    }

    public static function validarToken($token) {
        $secret = JWT_SECRET;

        $parts = explode('.', $token);
        if (count($parts) !== 3) return false;

        list($header, $payload, $signature) = $parts;

        $validSignature = self::base64UrlEncode(
            hash_hmac('sha256', "$header.$payload", $secret, true)
        );

        if ($signature !== $validSignature) return false;

        $payloadArray = json_decode(self::base64UrlDecode($payload), true);

        if (!$payloadArray) return false;
        if (isset($payloadArray['exp']) && $payloadArray['exp'] < time()) return false;

        return $payloadArray;
    }

    private static function base64UrlEncode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private static function base64UrlDecode($data) {
        return base64_decode(strtr($data, '-_', '+/'));
    }
}
