<?php
namespace Generic;

class Endpoint {
    private $controllerClass;

    public function __construct($controllerClass) {
        $this->controllerClass = $controllerClass;
    }

    public function run($acao, $id = null) {

        if (!class_exists($this->controllerClass)) {
            Retorno::error('Controller não encontrado: ' . $this->controllerClass, 500);
        }

        $ctrl = new $this->controllerClass();

        if ($this->controllerClass === 'Controller\\Auth') {

            if ($acao === Acao::CREATE && method_exists($ctrl, 'post')) {
                return $ctrl->post();
            }

            Retorno::error("Ação não implementada em Auth", 501);
        }

        switch ($acao) {
            case Acao::LIST:
                if (method_exists($ctrl, 'listar')) return $ctrl->listar();
                break;

            case Acao::GET:
                if (method_exists($ctrl, 'buscar')) return $ctrl->buscar($id);
                break;

            case Acao::CREATE:
                if (method_exists($ctrl, 'inserir')) return $ctrl->inserir();
                break;

            case Acao::UPDATE:
                if (method_exists($ctrl, 'atualizar')) return $ctrl->atualizar($id);
                break;

            case Acao::DELETE:
                if (method_exists($ctrl, 'deletar')) return $ctrl->deletar($id);
                break;
        }

        Retorno::error('Ação não implementada para este controller', 501);
    }
}
