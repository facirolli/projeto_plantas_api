<?php
namespace Generic;

class AuthMiddleware {

    public static function proteger() {
        $headers = getallheaders();

        if (!isset($headers['Authorization'])) {
            Retorno::error('Token ausente', 401);
        }

        $token = str_replace('Bearer ', '', $headers['Authorization']);
        $payload = JwtHelper::validarToken($token);

        if (!$payload) {
            Retorno::error('Token inválido ou expirado', 401);
        }

        return $payload; 
    }
}
