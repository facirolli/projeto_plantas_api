<?php
namespace Controller;

use Generic\Controller as BaseController;
use Generic\AuthMiddleware;
use Service\CuidadoService;

class Cuidado extends BaseController {
    private $service;

    public function __construct() {
        $this->service = new CuidadoService();
    }

    public function listar() {
        AuthMiddleware::defender();
        
        $rs = $this->service->listar();
        $this->sendSuccess($rs);
    }

    public function buscar($id) {
        AuthMiddleware::defender();

        if (empty($id)) {
            $this->sendError('ID não informado', 400);
        }

        $rs = $this->service->buscar((int)$id);

        if ($rs) {
            $this->sendSuccess($rs);
        }

        $this->sendError('Cuidado não encontrado', 404);
    }

    public function inserir() {
        AuthMiddleware::defender();

        $data = $this->getJsonInput();
        $result = $this->service->inserir($data);

        if ($result['success']) {
            $this->sendSuccess($result['data'], 'Cuidado criado', 201);
        }

        $this->sendError($result['message'], 400, $result['errors'] ?? null);
    }

    public function atualizar($id) {
        AuthMiddleware::defender();

        if (empty($id)) {
            $this->sendError('ID não informado', 400);
        }

        $data = $this->getJsonInput();
        $result = $this->service->atualizar((int)$id, $data);

        if ($result['success']) {
            $this->sendSuccess($result['data'], 'Cuidado atualizado');
        }

        $this->sendError($result['message'], 400, $result['errors'] ?? null);
    }

    public function deletar($id) {
        AuthMiddleware::defender();

        if (empty($id)) {
            $this->sendError('ID não informado', 400);
        }

        $result = $this->service->deletar((int)$id);

        if ($result['success']) {
            $this->sendSuccess(null, 'Cuidado excluído');
        }

        $this->sendError($result['message'], 400);
    }
}
