<?php
namespace Controller;

use Generic\Controller;
use Service\AuthService;

class Auth extends Controller {

    public function post() {
        $data = json_decode(file_get_contents("php://input"), true);

        if (!$data || !isset($data['username']) || !isset($data['senha'])) {
            return $this->sendError("Usuário e senha são obrigatórios", 400);
        }

        $service = new AuthService();
        $res = $service->login($data['username'], $data['senha']);

        if (!$res['ok']) {
            return $this->sendError($res['message'], 401);
        }

        return $this->sendSuccess($res['data'], $res['message'], 200);
    }

    public function create() {
        return $this->post();
    }
}
