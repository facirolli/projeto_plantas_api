<?php
namespace DAO;

use Generic\MysqlFactory;
use PDO;

class PlantaDAO {
    private $pdo;

    public function __construct() {
        $this->pdo = MysqlFactory::getConnection();
    }

    // Listar todas as plantas
    public function findAll() {
        try {
            $stmt = $this->pdo->query(
                'SELECT id, nome_cientifico, nome_popular FROM plantas'
            );

            return $stmt->fetchAll(PDO::FETCH_ASSOC);

        } catch (\Exception $e) {
            error_log($e->getMessage());
            throw new \Exception('Erro ao listar plantas');
        }
    }

    // Buscar planta por ID
    public function findById($id) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT id, nome_cientifico, nome_popular 
                 FROM plantas 
                 WHERE id = :id'
            );

            $stmt->execute([':id' => $id]);
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

        } catch (\Exception $e) {
            error_log($e->getMessage());
            throw new \Exception('Erro ao buscar planta');
        }
    }

    // Inserir planta
    public function insert($data) {
        try {
            $sql = 'INSERT INTO plantas (nome_cientifico, nome_popular)
                    VALUES (:nome_cientifico, :nome_popular)';

            $stmt = $this->pdo->prepare($sql);

            $ok = $stmt->execute([
                ':nome_cientifico' => $data['nome_cientifico'],
                ':nome_popular'    => $data['nome_popular'],
            ]);

            if ($ok) {
                return (int)$this->pdo->lastInsertId();
            }

            return false;

        } catch (\Exception $e) {
            error_log($e->getMessage());
            throw new \Exception('Erro ao inserir planta');
        }
    }

    // Atualizar planta
    public function update($id, $data) {
        try {
            $sql = 'UPDATE plantas 
                    SET nome_cientifico = :nome_cientifico, 
                        nome_popular = :nome_popular
                    WHERE id = :id';

            $stmt = $this->pdo->prepare($sql);

            return $stmt->execute([
                ':nome_cientifico' => $data['nome_cientifico'],
                ':nome_popular'    => $data['nome_popular'],
                ':id'              => $id
            ]);

        } catch (\Exception $e) {
            error_log($e->getMessage());
            throw new \Exception('Erro ao atualizar planta');
        }
    }

    // Deletar planta
    public function delete($id) {
        try {
            $stmt = $this->pdo->prepare('DELETE FROM plantas WHERE id = :id');
            return $stmt->execute([':id' => $id]);

        } catch (\Exception $e) {
            error_log($e->getMessage());
            throw new \Exception('Erro ao excluir planta');
        }
    }
}
