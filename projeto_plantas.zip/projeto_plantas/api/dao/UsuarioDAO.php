<?php
namespace DAO;

use Generic\MysqlFactory;
use PDO;

class UsuarioDAO {
    private $pdo;

    public function __construct() {
        $this->pdo = MysqlFactory::getConnection();
    }

    public function findAll() {
        try {
            $stmt = $this->pdo->query(
                'SELECT id, nome, email FROM usuarios'
            );
            return $stmt->fetchAll(PDO::FETCH_ASSOC);

        } catch (\Exception $e) {
            error_log($e->getMessage());
            throw new \Exception('Erro ao listar usuarios');
        }
    }

    public function findById($id) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT id, nome, email 
                 FROM usuarios 
                 WHERE id = :id'
            );

            $stmt->execute([':id' => $id]);
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

        } catch (\Exception $e) {
            error_log($e->getMessage());
            throw new \Exception('Erro ao buscar usuario');
        }
    }

    public function insert($data) {
        try {
            $sql = 'INSERT INTO usuarios (nome, email) 
                    VALUES (:nome, :email)';

            $stmt = $this->pdo->prepare($sql);

            $ok = $stmt->execute([
                ':nome'     => $data['nome'],
                ':email'    => $data['email']
            ]);

            if ($ok) {
                return (int)$this->pdo->lastInsertId();
            }

            return false;

        } catch (\Exception $e) {
            error_log($e->getMessage());
            throw new \Exception('Erro ao inserir usuario');
        }
    }

    public function update($id, $data) {
        try {
            $sql = 'UPDATE usuarios 
                    SET nome = :nome, email = :email 
                    WHERE id = :id';

            $stmt = $this->pdo->prepare($sql);

            return $stmt->execute([
                ':nome'     => $data['nome'],
                ':email'    => $data['email'],
                ':id'       => $id
            ]);

        } catch (\Exception $e) {
            error_log($e->getMessage());
            throw new \Exception('Erro ao atualizar usuario');
        }
    }

    public function delete($id) {
        try {
            $stmt = $this->pdo->prepare(
                'DELETE FROM usuarios WHERE id = :id'
            );

            return $stmt->execute([':id' => $id]);

        } catch (\Exception $e) {
            error_log($e->getMessage());
            throw new \Exception('Erro ao excluir usuario');
        }
    }
}
