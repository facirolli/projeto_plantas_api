<?php
namespace DAO;

use Generic\MysqlFactory;
use PDO;

class CuidadoDAO {
    private $pdo;

    public function __construct() {
        $this->pdo = MysqlFactory::getConnection();
    }

    // Listar todos os cuidados
    public function findAll() {
        try {
            $stmt = $this->pdo->query(
                'SELECT id, usuario_id, planta_id, tipo_cuidado, frequencia FROM cuidados'
            );

            return $stmt->fetchAll(PDO::FETCH_ASSOC);

        } catch (\Exception $e) {
            error_log($e->getMessage());
            throw new \Exception('Erro ao listar cuidados');
        }
    }

    // Buscar cuidado por ID
    public function findById($id) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT id, usuario_id, planta_id, tipo_cuidado, frequencia 
                 FROM cuidados 
                 WHERE id = :id'
            );

            $stmt->execute([':id' => $id]);
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

        } catch (\Exception $e) {
            error_log($e->getMessage());
            throw new \Exception('Erro ao buscar cuidado');
        }
    }

    // Inserir cuidado
    public function insert($data) {
        try {
            $sql = 'INSERT INTO cuidados (usuario_id, planta_id, tipo_cuidado, frequencia) 
                    VALUES (:usuario_id, :planta_id, :tipo_cuidado, :frequencia)';

            $stmt = $this->pdo->prepare($sql);

            $ok = $stmt->execute([
                ':usuario_id'  => $data['usuario_id'],
                ':planta_id'   => $data['planta_id'],
                ':tipo_cuidado'=> $data['tipo_cuidado'],
                ':frequencia'  => $data['frequencia']
            ]);

            if ($ok) {
                return (int)$this->pdo->lastInsertId();
            }

            return false;

        } catch (\Exception $e) {
            error_log($e->getMessage());
            throw new \Exception('Erro ao inserir cuidado');
        }
    }

    // Atualizar cuidado
    public function update($id, $data) {
        try {
            $sql = 'UPDATE cuidados 
                    SET usuario_id = :usuario_id, planta_id = :planta_id, tipo_cuidado = :tipo_cuidado, frequencia = :frequencia 
                    WHERE id = :id';

            $stmt = $this->pdo->prepare($sql);

            return $stmt->execute([
                ':usuario_id'  => $data['usuario_id'],
                ':planta_id'   => $data['planta_id'],
                ':tipo_cuidado'=> $data['tipo_cuidado'],
                ':frequencia'  => $data['frequencia'],
                ':id'          => $id
            ]);

        } catch (\Exception $e) {
            error_log($e->getMessage());
            throw new \Exception('Erro ao atualizar cuidado');
        }
    }

    // Deletar cuidado
    public function delete($id) {
        try {
            $stmt = $this->pdo->prepare(
                'DELETE FROM cuidados WHERE id = :id'
            );

            return $stmt->execute([':id' => $id]);

        } catch (\Exception $e) {
            error_log($e->getMessage());
            throw new \Exception('Erro ao excluir cuidado');
        }
    }
}
