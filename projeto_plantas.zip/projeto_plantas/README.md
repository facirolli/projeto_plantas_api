# Projeto Plantas

Este projeto foi feito como trabalho acadêmico usando arquitetura MVC (Model-View-Controller) em conjunto com os padrões DAO (Data Access Object) e Service.  
O sistema permite gerenciar usuarios, plantas e os seus donos(usuarios) e os cuidados de cada uma delas de forma prática e organizada.

------------------------------------------------------------

# Metodos utilizados
- PHP
- MySQL (via XAMPP)
- HTML / CSS
- Padrões de Projeto: MVC, DAO, Service
- Apache (servidor local do XAMPP)

------------------------------------------------------------

# Estrutura do projeto
```
projeto_plantas/
 ┣ controller/         Controllers (PlantaController, UsuarioController, CuidadoController)
 ┣ dao/                DAOs que acessa acesso ao banco
 ┣ generic/            Autoload, conexão e classes utilitárias
 ┣ service/            Services com regras de negócio
 ┣ views/ (ou public/) Views (formulários e listas)
 ┣ css/                Estilos da aplicação
 ┣ index.php           Front Controller (entrada principal)
 ┗ .htaccess           Regras para URLs amigáveis
 
```

------------------------------------------------------------

# Banco de Dados
- Banco: plantas_db
- Tabelas:
  - usuarios -- cadastro de usuarios
  - cuidados -- mostra o cuidado das plantas, tambem mostra o dono da planta ( usuario)
  - plantas -- registro das plantas feitas

O arquivo plantas_db.sql deve ser importado no phpMyAdmin para criar a estrutura do banco.

------------------------------------------------------------

# Funcionalidades
- CRUD completo de Doadores, Doações e Instituições
- Interface HTML + CSS
- Dashboard inicial com cards de navegação
- URLs amigáveis com .htaccess
- Separação de responsabilidades com MVC, DAO e Service

------------------------------------------------------------

# Autor
- Sergio Roberto S de F Neto 5158210
- Ricardo Facirolli 5158706
