<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title><?= isset($planta['id']) ? 'Editar Planta' : 'Nova Planta' ?></title>
    <link rel="stylesheet" href="/projeto_plantas/css/style.css">
</head>
<body>

    <h2><?= isset($planta['id']) ? 'Editar Planta' : 'Nova Planta' ?></h2>

    <form method="POST">
        <label>Nome Científico:</label>
        <input type="text" name="nome_cientifico" value="<?= $planta['nome_cientifico'] ?? '' ?>" required><br>

        <label>Nome Popular:</label>
        <input type="text" name="nome_popular" value="<?= $planta['nome_popular'] ?? '' ?>" required><br>

        <button type="submit" class="btn">Salvar</button>
    </form>

    <?php if (!empty($erro)): ?>
        <p style="color:red;"><?= htmlspecialchars($erro) ?></p>
    <?php endif; ?>

    <p>
        <a class="btn" href="/projeto_plantas/index.php?controller=Planta&action=listar">Voltar à lista</a> | 
        <a class="btn" href="/projeto_plantas/index.php">🏠 Início</a>
    </p>

</body>
</html>
