<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Plantas</title>
    <link rel="stylesheet" href="/projeto_plantas/css/style.css">
</head>
<body>

    <h2>Lista de Plantas</h2>

    <p>
        <a class="btn" href="/projeto_plantas/index.php?controller=Planta&action=criar">🌿 Nova Planta</a> | 
        <a class="btn" href="/projeto_plantas/index.php">🏠 Voltar ao Início</a>
    </p>

    <table>
        <tr>
            <th>ID</th>
            <th>Nome Cientifico</th>
            <th>Nome Popular</th>
            <th>Ações</th>
        </tr>
        <?php if (!empty($plantas)): ?>
            <?php foreach ($plantas as $planta): ?>
                <tr>
                    <td><?= htmlspecialchars($planta['id']) ?></td>
                    <td><?= htmlspecialchars($planta['nome_cientifico']) ?></td>
                    <td><?= htmlspecialchars($planta['nome_popular']) ?></td>
                    <td>
                        <a class="btn" href="/projeto_plantas/index.php?controller=Planta&action=editar&id=<?= $planta['id'] ?>">✏️ Editar</a>
                        <a class="btn" href="/projeto_plantas/index.php?controller=Planta&action=deletar&id=<?= $planta['id'] ?>" onclick="return confirm('Excluir esta planta?')">🗑️ Excluir</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="7">Nenhuma planta cadastrada.</td></tr>
        <?php endif; ?>
    </table>

</body>
</html>
