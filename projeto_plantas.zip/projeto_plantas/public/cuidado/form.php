<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title><?= isset($cuidado['id']) ? 'Editar Cuidado' : 'Novo Cuidado' ?></title>
    <link rel="stylesheet" href="/projeto_plantas/css/style.css">
</head>
<body>

    <h2><?= isset($cuidado['id']) ? 'Editar Cuidado' : 'Novo Cuidado' ?></h2>

    <form method="POST">

        <!-- Selecionar Usuário -->
        <label>Usuário:</label>
        <select name="usuario_id" required>
            <option value="">Selecione um usuário</option>
            <?php foreach ($usuarios as $usuario): ?>
                <option value="<?= $usuario['id'] ?>"
                    <?= isset($cuidado['usuario_id']) && $cuidado['usuario_id'] == $usuario['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($usuario['nome']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <br>

        <!-- Selecionar Planta -->
        <label>Planta:</label>
        <select name="planta_id" required>
            <option value="">Selecione uma planta</option>
            <?php foreach ($plantas as $planta): ?>
                <option value="<?= $planta['id'] ?>"
                    <?= isset($cuidado['planta_id']) && $cuidado['planta_id'] == $planta['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($planta['nome_popular']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <br>

        <!-- Tipo de cuidado -->
        <label>Tipo de Cuidado:</label>
        <input type="text" name="tipo_cuidado" value="<?= $cuidado['tipo_cuidado'] ?? '' ?>" required><br>

        <!-- Frequência -->
        <label>Frequência:</label>
        <input type="text" name="frequencia" value="<?= $cuidado['frequencia'] ?? '' ?>" required><br>

        <button type="submit" class="btn">Salvar</button>
    </form>

    <?php if (!empty($erro)): ?>
        <p style="color:red;"><?= htmlspecialchars($erro) ?></p>
    <?php endif; ?>

    <p>
        <a class="btn" href="/projeto_plantas/index.php?controller=Cuidado&action=listar">Voltar à lista</a> | 
        <a class="btn" href="/projeto_plantas/index.php">🏠 Início</a>
    </p>

</body>
</html>
