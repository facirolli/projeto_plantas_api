<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Cuidados</title>
    <link rel="stylesheet" href="/projeto_plantas/css/style.css">
</head>
<body>

    <h2>Lista de Cuidados</h2>

    <p>
        <a class="btn" href="/projeto_plantas/index.php?controller=Cuidado&action=criar">➕ Novo Cuidado</a> | 
        <a class="btn" href="/projeto_plantas/index.php">🏠 Voltar ao Início</a>
    </p>

    <table>
        <tr>
            <th>ID</th>
            <th>Usuário</th>
            <th>Planta</th>
            <th>Tipo de Cuidado</th>
            <th>Frequência</th>
            <th>Ações</th>
        </tr>
        <?php if (!empty($cuidados)): ?>
            <?php foreach ($cuidados as $i): ?>
                <tr>
                    <td><?= htmlspecialchars($i['id']) ?></td>
                    <td><?= htmlspecialchars($i['usuario_nome']) ?></td>
                    <td><?= htmlspecialchars($i['planta_nome']) ?></td>
                    <td><?= htmlspecialchars($i['tipo_cuidado']) ?></td>
                    <td><?= htmlspecialchars($i['frequencia']) ?></td>
                    <td>
                        <a class="btn" href="/projeto_plantas/index.php?controller=Cuidado&action=editar&id=<?= $i['id'] ?>">✏️ Editar</a>
                        <a class="btn" href="/projeto_plantas/index.php?controller=Cuidado&action=deletar&id=<?= $i['id'] ?>" onclick="return confirm('Excluir este cuidado?')">🗑️ Excluir</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="6">Nenhum cuidado cadastrado.</td></tr>
        <?php endif; ?>
    </table>

</body>
</html>
