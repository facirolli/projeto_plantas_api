<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Usuarios</title>
    <link rel="stylesheet" href="/projeto_plantas/css/style.css">
</head>
<body>

    <h2>Lista de Usuarios</h2>

    <p>
        <a class="btn" href="/projeto_plantas/index.php?controller=Usuario&action=criar">➕ Novo Usuario</a> | 
        <a class="btn" href="/projeto_plantas/index.php">🏠 Voltar ao Início</a>
    </p>

    <table>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Email</th>
            <th>Ações</th>
        </tr>
        <?php if (!empty($usuarios)): ?>
            <?php foreach ($usuarios as $usuario): ?>
                <tr>
                    <td><?= htmlspecialchars($usuario['id']) ?></td>
                    <td><?= htmlspecialchars($usuario['nome']) ?></td>
                    <td><?= htmlspecialchars($usuario['email']) ?></td>
                    <td>
                        <a class="btn" href="/projeto_plantas/index.php?controller=Usuario&action=editar&id=<?= $usuario['id'] ?>">✏️ Editar</a>
                        <a class="btn" href="/projeto_plantas/index.php?controller=Usuario&action=deletar&id=<?= $usuario['id'] ?>" onclick="return confirm('Excluir este usuario?')">🗑️ Excluir</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="4">Nenhum usuario cadastrado.</td></tr>
        <?php endif; ?>
    </table>

</body>
</html>
