<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title><?= isset($doador['id']) ? 'Editar Doador' : 'Novo Doador' ?></title>
    <link rel="stylesheet" href="/projeto_plantas/css/style.css">
</head>
<body>

    <h2><?= isset($doador['id']) ? 'Editar Doador' : 'Novo Doador' ?></h2>

    <form method="POST">
        <label>Nome:</label>
        <input type="text" name="nome" value="<?= $doador['nome'] ?? '' ?>" required><br>

        <label>Email:</label>
        <input type="email" name="email" value="<?= $doador['email'] ?? '' ?>" required><br>

        <button type="submit" class="btn">Salvar</button>
    </form>

    <?php if (!empty($erro)): ?>
        <p style="color:red;"><?= htmlspecialchars($erro) ?></p>
    <?php endif; ?>

    <p>
        <a class="btn" href="/projeto_plantas/index.php?controller=Usuario&action=listar">Voltar à lista</a> | 
        <a class="btn" href="/projeto_plantas/index.php">🏠 Início</a>
    </p>

</body>
</html>
