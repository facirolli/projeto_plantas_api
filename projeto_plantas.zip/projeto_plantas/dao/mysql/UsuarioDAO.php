<?php
require_once __DIR__ . '/../../generic/MysqlFactory.php';

class UsuarioDAO {
    private $factory;

    public function __construct() {
        $this->factory = new MysqlFactory();
    }

    public function listar() {
        $sql = "SELECT id, nome, email FROM usuarios ORDER BY id DESC";
        return $this->factory->banco->executar($sql)->fetchAll();
    }

    public function buscarPorId($id) {
        $sql = "SELECT id, nome, email FROM usuarios WHERE id = ?";
        return $this->factory->banco->executar($sql, [$id])->fetch();
    }

    public function inserir($dados) {
        $sql = "INSERT INTO usuarios (nome, email) VALUES (?, ?)";
        $this->factory->banco->executar($sql, [$dados['nome'], $dados['email']]);
        return $this->factory->banco->executar("SELECT LAST_INSERT_ID()")->fetchColumn();
    }

    public function atualizar($id, $dados) {
        $sql = "UPDATE usuarios SET nome = ?, email = ? WHERE id = ?";
        return $this->factory->banco->executar($sql, [$dados['nome'], $dados['email'], $id]);
    }

    public function deletar($id) {
        $sql = "DELETE FROM usuarios WHERE id = ?";
        return $this->factory->banco->executar($sql, [$id]);
    }
}
