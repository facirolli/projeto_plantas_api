<?php
require_once __DIR__ . '/../../generic/MysqlFactory.php';

class PlantaDAO {
    private $factory;

    public function __construct() {
        $this->factory = new MysqlFactory();
    }

    // Listar todas as plantas
    public function listar() {
        $sql = "SELECT id, nome_cientifico, nome_popular
                FROM plantas
                ORDER BY id DESC";
        return $this->factory->banco->executar($sql)->fetchAll();
    }

    // Buscar planta por ID
    public function buscarPorId($id) {
        $sql = "SELECT id, nome_cientifico, nome_popular
                FROM plantas
                WHERE id = ?";
        return $this->factory->banco->executar($sql, [$id])->fetch();
    }

    // Inserir nova planta
    public function inserir($dados) {
        $sql = "INSERT INTO plantas (nome_cientifico, nome_popular)
                VALUES (?, ?)";
        $this->factory->banco->executar($sql, [
            $dados['nome_cientifico'],
            $dados['nome_popular']
        ]);
        return $this->factory->banco->executar("SELECT LAST_INSERT_ID()")->fetchColumn();
    }

    // Atualizar planta
    public function atualizar($id, $dados) {
        $sql = "UPDATE plantas 
                SET nome_cientifico = ?, nome_popular = ?
                WHERE id = ?";
        return $this->factory->banco->executar($sql, [
            $dados['nome_cientifico'],
            $dados['nome_popular'],
            $id
        ]);
    }

    // Deletar planta
    public function deletar($id) {
        $sql = "DELETE FROM plantas WHERE id = ?";
        return $this->factory->banco->executar($sql, [$id]);
    }
}
