<?php
require_once __DIR__ . '/../../generic/MysqlFactory.php';

class CuidadoDAO {
    private $factory;

    public function __construct() {
        $this->factory = new MysqlFactory();
    }

    // Listar todos os cuidados com nomes de usuário e planta
    public function listar() {
        $sql = "SELECT c.id, c.tipo_cuidado, c.frequencia,
                       u.nome AS usuario_nome,
                       p.nome_popular AS planta_nome
                FROM cuidados c
                LEFT JOIN usuarios u ON c.usuario_id = u.id
                LEFT JOIN plantas p ON c.planta_id = p.id
                ORDER BY c.id DESC";
        return $this->factory->banco->executar($sql)->fetchAll();
    }

    // Buscar cuidado por ID com nomes
    public function buscarPorId($id) {
        $sql = "SELECT c.id, c.tipo_cuidado, c.frequencia,
                       u.nome AS usuario_nome,
                       p.nome_popular AS planta_nome
                FROM cuidados c
                LEFT JOIN usuarios u ON c.usuario_id = u.id
                LEFT JOIN plantas p ON c.planta_id = p.id
                WHERE c.id = ?";
        return $this->factory->banco->executar($sql, [$id])->fetch();
    }

    // Inserir novo cuidado
    public function inserir($dados) {
        $sql = "INSERT INTO cuidados (usuario_id, planta_id, tipo_cuidado, frequencia)
                VALUES (?, ?, ?, ?)";
        $this->factory->banco->executar($sql, [
            $dados['usuario_id'],
            $dados['planta_id'],
            $dados['tipo_cuidado'],
            $dados['frequencia']
        ]);
        return $this->factory->banco->executar("SELECT LAST_INSERT_ID()")->fetchColumn();
    }

    // Atualizar cuidado
    public function atualizar($id, $dados) {
        $sql = "UPDATE cuidados 
                SET usuario_id = ?, planta_id = ?, tipo_cuidado = ?, frequencia = ?
                WHERE id = ?";
        return $this->factory->banco->executar($sql, [
            $dados['usuario_id'],
            $dados['planta_id'],
            $dados['tipo_cuidado'],
            $dados['frequencia'],
            $id
        ]);
    }

    // Deletar cuidado
    public function deletar($id) {
        $sql = "DELETE FROM cuidados WHERE id = ?";
        return $this->factory->banco->executar($sql, [$id]);
    }
}
