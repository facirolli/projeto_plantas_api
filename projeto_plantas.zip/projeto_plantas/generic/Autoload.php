<?php
spl_autoload_register(function ($class) {
    $candidates = [
        __DIR__ . '/../controller/' . $class . '.php',
        __DIR__ . '/../service/' . $class . '.php',
        __DIR__ . '/../dao/mysql/' . $class . '.php',
        __DIR__ . '/' . $class . '.php'
    ];

    foreach ($candidates as $file) {
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});
