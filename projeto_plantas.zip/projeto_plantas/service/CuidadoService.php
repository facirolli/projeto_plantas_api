<?php
require_once __DIR__ . '/../dao/mysql/CuidadoDAO.php';

class CuidadoService {
    private $dao;

    public function __construct() {
        $this->dao = new CuidadoDAO();
    }

    public function listar() {
        return $this->dao->listar();
    }

    public function buscarPorId($id) {
        return $this->dao->buscarPorId($id);
    }

    public function inserir($dados) {
        return $this->dao->inserir($dados);
    }

    public function atualizar($id, $dados) {
        return $this->dao->atualizar($id, $dados);
    }

    public function deletar($id) {
        return $this->dao->deletar($id);
    }
}
